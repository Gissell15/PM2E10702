package com.PM2E02.MP2E02;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.PM2E02.MP2E02.models.Herramientas;
import com.PM2E02.MP2E02.models.Tecnicos;
import com.PM2E02.MP2E02.models.configuration.Transacciones;
import com.example.pm2e02.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AsignarActivity extends AppCompatActivity {

    Spinner spinnerHerramientas, spinnerTecnicos;
    EditText txtFechaInicio, txtFechaFin;
    Button btnConfirmar;
    List<Herramientas> listaHerramientas;
    List<Tecnicos> listaTecnicos;
    final Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asignar);

        spinnerHerramientas = findViewById(R.id.spinner_herramientas);
        spinnerTecnicos = findViewById(R.id.spinner_tecnicos);
        txtFechaInicio = findViewById(R.id.txt_fecha_inicio);
        txtFechaFin = findViewById(R.id.txt_fecha_fin);
        btnConfirmar = findViewById(R.id.btn_confirmar_asignacion);

        txtFechaInicio.setFocusable(false);
        txtFechaFin.setFocusable(false);

        txtFechaInicio.setOnClickListener(v -> showDatePicker(txtFechaInicio));
        txtFechaFin.setOnClickListener(v -> showDatePicker(txtFechaFin));

        cargarDatos();

        btnConfirmar.setOnClickListener(v -> {
            if (validar()) {
                mostrarConfirmacion();
            }
        });
    }

    private void showDatePicker(EditText editText) {
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            editText.setText(sdf.format(calendar.getTime()));
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void cargarDatos() {
        SQLliteconexion conexion = new SQLliteconexion(this);
        SQLiteDatabase db = conexion.getReadableDatabase();

        listaHerramientas = new ArrayList<>();
        Cursor cursorH = db.rawQuery("SELECT * FROM " + Transacciones.tbHerramientas + " WHERE " + Transacciones.h_estado + " = 'DISPONIBLE'", null);
        while (cursorH.moveToNext()) {
            listaHerramientas.add(new Herramientas(cursorH.getInt(0), cursorH.getString(1), "", "", "", ""));
        }
        cursorH.close();

        spinnerHerramientas.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getNombresHerramientas()));

        listaTecnicos = new ArrayList<>();
        db.execSQL("INSERT OR IGNORE INTO " + Transacciones.tbTecnicos + " (id, nombre) VALUES (1, 'Juan Perez'), (2, 'Maria Lopez'), (3, 'Carlos Ruiz')");
        
        Cursor cursorT = db.rawQuery("SELECT * FROM " + Transacciones.tbTecnicos, null);
        while (cursorT.moveToNext()) {
            listaTecnicos.add(new Tecnicos(cursorT.getInt(0), cursorT.getString(1), "", ""));
        }
        cursorT.close();

        spinnerTecnicos.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaTecnicos));
        db.close();
    }

    private List<String> getNombresHerramientas() {
        List<String> nombres = new ArrayList<>();
        for (Herramientas h : listaHerramientas) nombres.add(h.getNombre());
        return nombres;
    }

    private boolean validar() {
        if (listaHerramientas.isEmpty()) {
            Toast.makeText(this, "No hay herramientas disponibles", Toast.LENGTH_SHORT).show();
            return false;
        }
        String inicioStr = txtFechaInicio.getText().toString();
        String finStr = txtFechaFin.getText().toString();

        if (inicioStr.isEmpty() || finStr.isEmpty()) {
            Toast.makeText(this, "Las fechas son obligatorias", Toast.LENGTH_SHORT).show();
            return false;
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date dateInicio = sdf.parse(inicioStr);
            Date dateFin = sdf.parse(finStr);

            if (dateFin.before(dateInicio)) {
                Toast.makeText(this, "La fecha de fin no puede ser menor a la de inicio", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private void mostrarConfirmacion() {
        Herramientas h = listaHerramientas.get(spinnerHerramientas.getSelectedItemPosition());
        Tecnicos t = (Tecnicos) spinnerTecnicos.getSelectedItem();
        String inicio = txtFechaInicio.getText().toString();
        String fin = txtFechaFin.getText().toString();

        new AlertDialog.Builder(this)
                .setTitle("Confirmar Asignación")
                .setMessage("¿Confirmar asignación de " + h.getNombre() + " a " + t.getNombre() + "?\nInicio: " + inicio + "\nFin: " + fin)
                .setPositiveButton("Confirmar", (dialog, which) -> guardarAsignacion(h, t, inicio, fin))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void guardarAsignacion(Herramientas h, Tecnicos t, String inicio, String fin) {
        SQLliteconexion conexion = new SQLliteconexion(this);
        SQLiteDatabase db = conexion.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Transacciones.a_herramienta_id, h.getId());
        values.put(Transacciones.a_tecnico_id, t.getId());
        values.put(Transacciones.a_fecha_inicio, inicio);
        values.put(Transacciones.a_fecha_fin, fin);

        long result = db.insert(Transacciones.tbAsignaciones, null, values);

        if (result != -1) {
            db.execSQL("UPDATE " + Transacciones.tbHerramientas + " SET " + Transacciones.h_estado + " = 'ASIGNADA' WHERE " + Transacciones.h_id + " = " + h.getId());
            Toast.makeText(this, "Asignación registrada exitosamente", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }
}
