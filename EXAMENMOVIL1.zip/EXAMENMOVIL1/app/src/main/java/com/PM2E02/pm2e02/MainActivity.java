package com.PM2E02.pm2e02;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.PM2E02.mp011p2026.models.configuration.SQLliteconexion;
import com.PM2E02.mp011p2026.models.configuration.Transacciones;

public class MainActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int ACCESS_CAMERA = 101;

    EditText nombre, descripcion, especificaciones;
    ImageView foto;
    Button btnAgregar, btnFoto, btnAsignar, btnVerLista;
    String currentPhotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = findViewById(R.id.nombre_herramienta);
        descripcion = findViewById(R.id.descripcion_herramienta);
        especificaciones = findViewById(R.id.especificaciones_tecnicas);
        foto = findViewById(R.id.foto_herramienta);
        btnAgregar = findViewById(R.id.btn_agregar_herramienta);
        btnFoto = findViewById(R.id.btn_tomar_foto);
        btnAsignar = findViewById(R.id.btn_asignar);
        btnVerLista = findViewById(R.id.btn_ver_lista);

        btnFoto.setOnClickListener(v -> permisos());
        btnAgregar.setOnClickListener(v -> validarYGuardar());
        btnAsignar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AsignarActivity.class);
            startActivity(intent);
        });
        btnVerLista.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListaHerramientasActivity.class);
            startActivity(intent);
        });
    }

    private void permisos() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, ACCESS_CAMERA);
        } else {
            dispatchTakePictureIntent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == ACCESS_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            dispatchTakePictureIntent();
        }
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK && data != null) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            foto.setImageBitmap(imageBitmap);
            currentPhotoPath = "foto_" + System.currentTimeMillis() + ".jpg"; 
        }
    }

    private void validarYGuardar() {
        String name = nombre.getText().toString().trim();
        String desc = descripcion.getText().toString().trim();
        String spec = especificaciones.getText().toString().trim();

        if (name.isEmpty() || desc.isEmpty() || spec.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        if (name.length() < 3) {
            Toast.makeText(this, "El nombre debe tener al menos 3 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLliteconexion conexion = new SQLliteconexion(this);
        SQLiteDatabase db = conexion.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Transacciones.h_nombre, name);
        values.put(Transacciones.h_descripcion, desc);
        values.put(Transacciones.h_especificaciones, spec);
        values.put(Transacciones.h_foto_uri, currentPhotoPath);
        values.put(Transacciones.h_estado, "DISPONIBLE");

        long newRowId = db.insert(Transacciones.tbHerramientas, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Herramienta guardada con éxito", Toast.LENGTH_SHORT).show();
            limpiar();
        }
        db.close();
    }

    private void limpiar() {
        nombre.setText("");
        descripcion.setText("");
        especificaciones.setText("");
        foto.setImageResource(android.R.drawable.ic_menu_camera);
        currentPhotoPath = null;
    }
}
