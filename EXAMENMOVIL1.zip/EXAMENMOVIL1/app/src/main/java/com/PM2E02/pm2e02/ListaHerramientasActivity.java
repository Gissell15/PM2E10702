package com.PM2E02.pm2e02;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.PM2E02.mp011p2026.models.Herramientas;
import com.PM2E02.mp011p2026.models.configuration.SQLliteconexion;
import com.PM2E02.mp011p2026.models.configuration.Transacciones;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ListaHerramientasActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    HerramientasAdapter adapter;
    List<HerramientasAdapter.HerramientasConAsignacion> list;
    SearchView searchView;
    Button btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_herramientas);

        recyclerView = findViewById(R.id.recycler_view);
        searchView = findViewById(R.id.search_view);
        btnRegresar = findViewById(R.id.btn_regresar);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        obtenerDatos();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) { return false; }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });

        btnRegresar.setOnClickListener(v -> finish());
    }

    private void obtenerDatos() {
        SQLliteconexion conexion = new SQLliteconexion(this);
        SQLiteDatabase db = conexion.getReadableDatabase();
        list = new ArrayList<>();


        String query = "SELECT h.*, t." + Transacciones.t_nombre + " as tecnico_nombre, last_a." + Transacciones.a_fecha_fin + 
                ", last_a." + Transacciones.a_fecha_devolucion + 
                " FROM " + Transacciones.tbHerramientas + " h " +
                " LEFT JOIN (" +
                "   SELECT * FROM " + Transacciones.tbAsignaciones + 
                "   WHERE id IN (SELECT MAX(id) FROM " + Transacciones.tbAsignaciones + " GROUP BY " + Transacciones.a_herramienta_id + ")" +
                " ) last_a ON h." + Transacciones.h_id + " = last_a." + Transacciones.a_herramienta_id +
                " LEFT JOIN " + Transacciones.tbTecnicos + " t ON last_a." + Transacciones.a_tecnico_id + " = t." + Transacciones.t_id +
                " ORDER BY last_a." + Transacciones.a_fecha_fin + " ASC, h." + Transacciones.h_estado + " DESC";

        Cursor cursor = db.rawQuery(query, null);

        while (cursor.moveToNext()) {
            Herramientas h = new Herramientas(
                    cursor.getInt(0), cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), cursor.getString(4), cursor.getString(5)
            );
            
            list.add(new HerramientasAdapter.HerramientasConAsignacion(
                    h,
                    cursor.getString(cursor.getColumnIndexOrThrow("tecnico_nombre")),
                    cursor.getString(cursor.getColumnIndexOrThrow(Transacciones.a_fecha_fin)),
                    cursor.getString(cursor.getColumnIndexOrThrow(Transacciones.a_fecha_devolucion))
            ));
        }
        cursor.close();
        db.close();

        adapter = new HerramientasAdapter(list, this::mostrarOpciones);
        recyclerView.setAdapter(adapter);
    }

    private void mostrarOpciones(HerramientasAdapter.HerramientasConAsignacion item) {
        if (!"ASIGNADA".equals(item.getHerramienta().getEstado())) {
            compartirFicha(item);
            return;
        }

        String[] opciones = {"Marcar Devolución", "Compartir Ficha", "Cancelar"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Opciones: " + item.getHerramienta().getNombre());
        builder.setItems(opciones, (dialog, which) -> {
            if (which == 0) marcarDevolucion(item);
            else if (which == 1) compartirFicha(item);
        });
        builder.show();
    }

    private void marcarDevolucion(HerramientasAdapter.HerramientasConAsignacion item) {
        SQLliteconexion conexion = new SQLliteconexion(this);
        SQLiteDatabase db = conexion.getWritableDatabase();
        String fechaHoy = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        ContentValues vAsign = new ContentValues();
        vAsign.put(Transacciones.a_fecha_devolucion, fechaHoy);
        db.update(Transacciones.tbAsignaciones, vAsign, Transacciones.a_herramienta_id + " = ? AND " + Transacciones.a_fecha_devolucion + " IS NULL", new String[]{String.valueOf(item.getHerramienta().getId())});

        ContentValues vHerr = new ContentValues();
        vHerr.put(Transacciones.h_estado, "DISPONIBLE");
        db.update(Transacciones.tbHerramientas, vHerr, Transacciones.h_id + " = ?", new String[]{String.valueOf(item.getHerramienta().getId())});

        db.close();
        Toast.makeText(this, "Herramienta devuelta con éxito", Toast.LENGTH_SHORT).show();
        obtenerDatos();
    }

    private void compartirFicha(HerramientasAdapter.HerramientasConAsignacion item) {
        String resumen = "FICHA TÉCNICA\n" +
                "Herramienta: " + item.getHerramienta().getNombre() + "\n" +
                "Estado actual: " + item.getHerramienta().getEstado() + "\n" +
                "Especificaciones: " + item.getHerramienta().getEspecificaciones();
        
        if (item.getTecnicoNombre() != null) {
            resumen += "\nÚltimo Técnico: " + item.getTecnicoNombre();
        }

        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, resumen);
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(sendIntent, "Compartir Ficha vía:"));
    }

    private void filter(String text) {
        List<HerramientasAdapter.HerramientasConAsignacion> filteredList = new ArrayList<>();
        for (HerramientasAdapter.HerramientasConAsignacion item : list) {
            if (item.getHerramienta().getNombre().toLowerCase().contains(text.toLowerCase()) ||
                (item.getTecnicoNombre() != null && item.getTecnicoNombre().toLowerCase().contains(text.toLowerCase())) ||
                item.getHerramienta().getEspecificaciones().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.setFilteredList(filteredList);
    }
}
