package com.PM2E02.pm2e02;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.PM2E02.mp011p2026.models.Herramientas;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HerramientasAdapter extends RecyclerView.Adapter<HerramientasAdapter.ViewHolder> {

    private List<HerramientasConAsignacion> list;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(HerramientasConAsignacion item);
    }

    public HerramientasAdapter(List<HerramientasConAsignacion> list, OnItemClickListener listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_herramienta, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HerramientasConAsignacion item = list.get(position);
        holder.nombre.setText(item.getHerramienta().getNombre());
        holder.estado.setText(item.getHerramienta().getEstado());
        
        if (item.getTecnicoNombre() != null) {
            holder.tecnico.setText("Asignado a: " + item.getTecnicoNombre());
            holder.fechaFin.setText("Vence: " + item.getFechaFin());
        } else {
            holder.tecnico.setText("Sin asignar");
            holder.fechaFin.setText("");
        }


        int color = Color.LTGRAY;

        if (item.getFechaDevolucion() != null) {
            color = Color.parseColor("#4CAF50");
        } else if ("ASIGNADA".equals(item.getHerramienta().getEstado())) {
            color = Color.parseColor("#FFC107");
            
            if (item.getFechaFin() != null) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    Date fechaFin = sdf.parse(item.getFechaFin());
                    Date hoy = new Date();
                    
                    long diferenciaMilis = fechaFin.getTime() - hoy.getTime();
                    long diferenciaHoras = diferenciaMilis / (1000 * 60 * 60);

                    if (hoy.after(fechaFin)) {
                        color = Color.parseColor("#F44336");
                    } else if (diferenciaHoras <= 48) {
                        color = Color.parseColor("#FFC107");
                    } else {

                        color = Color.parseColor("#FFC107"); 
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }

        holder.itemView.findViewById(R.id.container).setBackgroundColor(color);
        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void setFilteredList(List<HerramientasConAsignacion> filteredList) {
        this.list = filteredList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombre, tecnico, estado, fechaFin;
        ImageView img;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.txt_nombre);
            tecnico = itemView.findViewById(R.id.txt_tecnico);
            estado = itemView.findViewById(R.id.txt_estado);
            fechaFin = itemView.findViewById(R.id.txt_fecha_fin);
            img = itemView.findViewById(R.id.img_herramienta);
        }
    }

    public static class HerramientasConAsignacion {
        private Herramientas herramienta;
        private String tecnicoNombre;
        private String fechaFin;
        private String fechaDevolucion;

        public HerramientasConAsignacion(Herramientas herramienta, String tecnicoNombre, String fechaFin, String fechaDevolucion) {
            this.herramienta = herramienta;
            this.tecnicoNombre = tecnicoNombre;
            this.fechaFin = fechaFin;
            this.fechaDevolucion = fechaDevolucion;
        }

        public Herramientas getHerramienta() { return herramienta; }
        public String getTecnicoNombre() { return tecnicoNombre; }
        public String getFechaFin() { return fechaFin; }
        public String getFechaDevolucion() { return fechaDevolucion; }
    }
}
